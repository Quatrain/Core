import { AuthParameters, AuthParametersKeys } from './Auth';
import { User } from '@quatrain/backend';
import { AuthInterface } from './types/AuthInterface';
export declare abstract class AbstractAuthAdapter implements AuthInterface {
    static UserClass: typeof User;
    protected _alias: string;
    protected _params: AuthParameters;
    constructor(params?: AuthParameters);
    setParam(key: AuthParametersKeys, value: any): void;
    getParam(key: AuthParametersKeys): any;
    set alias(alias: string);
    get alias(): string;
    abstract register(user: User, clearPassword?: string): Promise<any>;
    abstract signup(login: string, password: string): Promise<any>;
    abstract signout(user: User): Promise<any>;
    abstract update(user: User, updatable: any): Promise<any>;
    abstract delete(user: User): Promise<any>;
    abstract getAuthToken(token: string): any;
    abstract refreshToken(refreshToken: string): Promise<any>;
    abstract revokeAuthToken(token: string): any;
    abstract setCustomUserClaims(id: string, claims: any): any;
}

import { Core } from '@quatrain/core';
import { AbstractAuthAdapter } from './AbstractAuthAdapter';
import Middleware from './middlewares/AuthMiddleware';
export declare enum AuthAction {
    SIGNIN = "signin",
    SIGNUP = "signup",
    SIGNOUT = "signout"
}
/**
 * Authentication Parameters acceptable keys
 */
export type AuthParametersKeys = 'host' | 'alias' | 'middlewares' | 'config' | 'fixtures' | 'debug';
/**
 * Backend parameters interface
 */
export interface AuthParameters {
    host?: string;
    alias?: string;
    middlewares?: Middleware[];
    config?: any;
    fixtures?: any;
    debug?: boolean;
}
export interface AuthAdapter extends AbstractAuthAdapter {
}
export type AuthRegistry<T extends AbstractAuthAdapter> = {
    [x: string]: T;
};
export declare class Auth extends Core {
    static defaultProvider: string;
    static logger: any;
    static ERROR_EMAIL_EXISTS: string;
    protected static _providers: AuthRegistry<any>;
    static addProvider(provider: AbstractAuthAdapter, alias: string, setDefault?: boolean): void;
    static getProvider<T extends AbstractAuthAdapter>(alias?: string): T;
}

import { AbstractAuthAdapter } from './AbstractAuthAdapter';
import { User } from '@quatrain/backend';
import { AuthParameters } from './Auth';
/**
 * Mock Authentication Adapter for testing purposes
 */
export declare class MockAuthAdapter extends AbstractAuthAdapter {
    private registeredUsers;
    private tokens;
    private refreshTokens;
    constructor(params?: AuthParameters);
    register(user: User, clearPassword?: string): Promise<any>;
    signup(login: string, password: string): Promise<any>;
    signout(user: User): Promise<any>;
    update(user: User, updatable: any): Promise<any>;
    delete(user: User): Promise<any>;
    getAuthToken(token: string): any;
    refreshToken(refreshToken: string): Promise<any>;
    revokeAuthToken(token: string): any;
    setCustomUserClaims(id: string, claims: any): any;
    clearAll(): void;
    getUserByEmail(email: string): User | undefined;
    hasToken(token: string): boolean;
}
